"use strict";
exports.id = 947;
exports.ids = [947];
exports.modules = {

/***/ 4859:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ onedriveRequest),
/* harmony export */   "W": () => (/* binding */ request)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const request = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/onedrive/reply",
    timeout: 100000,
    headers: {
        "Content-Type": "application/json"
    }
});
request.interceptors.response.use((res)=>res.data);
const onedriveRequest = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/onedrive/onedriveApi",
    timeout: 100000,
    headers: {
        "Content-Type": "application/json"
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7947:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$5": () => (/* binding */ checkUploadList),
/* harmony export */   "_T": () => (/* binding */ uploadSuccess),
/* harmony export */   "qb": () => (/* binding */ Status),
/* harmony export */   "tV": () => (/* binding */ getUploadList),
/* harmony export */   "u0": () => (/* binding */ createUploadSession)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4859);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

var Status;
(function(Status) {
    Status["Pending"] = "pending";
    Status["Approved"] = "approved";
    Status["Rejected"] = "rejected";
})(Status || (Status = {}));
const createUploadSession = async (path, userName)=>{
    return (await ___WEBPACK_IMPORTED_MODULE_0__/* .onedriveRequest.post */ .B.post("/createUploadSession", {
        path,
        userName
    })).data.uploadUrl;
};
const uploadSuccess = async (data)=>{
    return await ___WEBPACK_IMPORTED_MODULE_0__/* .onedriveRequest.post */ .B.post("/uploadSuccess", data);
};
const getUploadList = async (page, size)=>{
    return (await ___WEBPACK_IMPORTED_MODULE_0__/* .onedriveRequest.get */ .B.get("/getUploadList", {
        params: {
            page,
            size
        }
    })).data;
};
const checkUploadList = async (id, status)=>{
    return (await ___WEBPACK_IMPORTED_MODULE_0__/* .onedriveRequest.post */ .B.post("/checkUploadList", {
        id,
        status
    })).data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
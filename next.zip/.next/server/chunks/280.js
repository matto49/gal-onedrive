"use strict";
exports.id = 280;
exports.ids = [280];
exports.modules = {

/***/ 7384:
/***/ ((module) => {

/**
 * This file contains the configuration for the API endpoints and tokens we use.
 *
 * - If you are a OneDrive International user, you would not have to change anything here.
 * - If you are not the admin of your OneDrive for Business account, you may need to define your own clientId/clientSecret,
 *   check documentation for more details.
 * - If you are using a E5 Subscription OneDrive for Business account, the direct links of your files are not the same here.
 *   In which case you would need to change directLinkRegex.
 */ 
module.exports = {
    // The clientId and clientSecret are used to authenticate the user with Microsoft Graph API using OAuth. You would
    // not need to change anything here if you can authenticate with your personal Microsoft account with OneDrive International.
    clientId: "b9137ca2-46fb-4f3f-be7a-c5bdc8b0a4bd",
    obfuscatedClientSecret: "U2FsdGVkX1/rbvxZ0WxdYfAauSaF3r6lzKAiXOYoxyU/mG3nkDAvERxj4pUzEjRTgMgB834v8UT/YMLHLamh+w==",
    // The redirectUri is the URL that the user will be redirected to after they have authenticated with Microsoft Graph API.
    // Likewise, you would not need to change redirectUri if you are using your personal Microsoft account with OneDrive International.
    redirectUri: "http://localhost",
    // These are the URLs of the OneDrive API endpoints. You would not need to change anything here if you are using OneDrive International
    // or E5 Subscription OneDrive for Business. You may need to change these if you are using OneDrive 世纪互联.
    authApi: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
    driveApi: "https://graph.microsoft.com/v1.0/me/drive",
    // The scope we require are listed here, in most cases you would not need to change this as well.
    scope: "user.read files.read.all offline_access",
    // Cache-Control header, check Vercel documentation for more details. The default settings imply:
    // - max-age=0: no cache for your browser
    // - s-maxage=0: cache is fresh for 60 seconds on the edge, after which it becomes stale
    // - stale-while-revalidate: allow serving stale content while revalidating on the edge
    // https://vercel.com/docs/concepts/edge-network/caching
    cacheControlHeader: "max-age=0, s-maxage=60, stale-while-revalidate"
};


/***/ }),

/***/ 5386:
/***/ ((module) => {

/**
 * This file contains the configuration used for customising the website, such as the folder to share,
 * the title, used Google fonts, site icons, contact info, etc.
 */ 
module.exports = {
    // This is what we use to identify who you are when you are initialising the website for the first time.
    // Make sure this is exactly the same as the email address you use to sign into your Microsoft account.
    // You can also put this in your Vercel's environment variable 'NEXT_PUBLIC_USER_PRINCIPLE_NAME' if you worry about
    // your email being exposed in public.
    userPrincipalName: "mattoTest@76qkz8.onmicrosoft.com",
    // [OPTIONAL] This is the website icon to the left of the title inside the navigation bar. It should be placed under the
    // /public directory of your GitHub project (not your OneDrive folder!), and referenced here by its relative path to /publi c.
    icon: "/icons/logo.png",
    // Prefix for KV Storage
    kvPrefix: process.env.KV_PREFIX || "",
    // The name of your website. Present alongside your icon.
    title: "Bokiboki Galgame Club",
    // The folder that you are to share publicly with onedrive-vercel-index. Use '/' if you want to share your root folder.
    baseDirectory: "/aoikaze",
    // [OPTIONAL] This represents the maximum number of items that one directory lists, pagination supported.
    // Do note that this is limited up to 200 items by the upstream OneDrive API.
    maxItems: 100,
    // [OPTIONAL] We use Google Fonts natively for font customisations.
    // You can check and generate the required links and names at https://fonts.google.com.
    // googleFontSans - the sans serif font used in onedrive-vercel-index.
    googleFontSans: "Inter",
    // googleFontMono - the monospace font used in onedrive-vercel-index.
    googleFontMono: "Fira Mono",
    // googleFontLinks -  an array of links for referencing the google font assets.
    googleFontLinks: [
        "https://fonts.googleapis.com/css2?family=Fira+Mono&family=Inter:wght@400;500;700&display=swap"
    ],
    // [OPTIONAL] The footer component of your website. You can write HTML here, but you need to escape double
    // quotes - changing " to \". You can write anything here, and if you like badges, generate some with https://shields.io
    footer: "Powered by onedrive-vercel-index. Maintained by Aoikaze Galgame Club.",
    // [OPTIONAL] This is where you specify the folders that are password protected. It is an array of paths pointing to all
    // the directories in which you have .password set. Check the documentation for details.
    protectedRoutes: [
        "/\uD83C\uDF1E Private folder/u-need-a-password",
        "/\uD83E\uDD5F Some test files/Protected route"
    ],
    // [OPTIONAL] Use "" here if you want to remove this email address from the nav bar.
    email: "",
    // [OPTIONAL] This is an array of names and links for setting your social information and links.
    // In the latest update, all brand icons inside font awesome is supported and the icon to render is based on the name
    // you provide. See the documentation for details.
    links: [],
    // This is a day.js-style datetime format string to format datetimes in the app. Ref to
    // https://day.js.org/docs/en/display/format for detailed specification. The default value is ISO 8601 full datetime
    // without timezone and replacing T with space.
    datetimeFormat: "YYYY-MM-DD HH:mm:ss"
};


/***/ }),

/***/ 8092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ec": () => (/* binding */ encodePath),
/* harmony export */   "GY": () => (/* binding */ checkAuthRoute),
/* harmony export */   "hP": () => (/* binding */ getAccessToken)
/* harmony export */ });
/* unused harmony exports getAuthTokenPath, default */
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7384);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5386);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config_site_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7086);
/* harmony import */ var _utils_protectedRouteHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4014);
/* harmony import */ var _utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6625);
/* harmony import */ var _raw__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(115);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__, _raw__WEBPACK_IMPORTED_MODULE_7__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__, _raw__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const basePath = path__WEBPACK_IMPORTED_MODULE_0__.posix.resolve("/", (_config_site_config__WEBPACK_IMPORTED_MODULE_3___default().baseDirectory));
const clientSecret = (0,_utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__/* .revealObfuscatedToken */ .Jj)((_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().obfuscatedClientSecret));
/**
 * Encode the path of the file relative to the base directory
 *
 * @param path Relative path of the file to the base directory
 * @returns Absolute path of the file inside OneDrive
 */ function encodePath(path) {
    let encodedPath = path__WEBPACK_IMPORTED_MODULE_0__.posix.join(basePath, path);
    if (encodedPath === "/" || encodedPath === "") {
        return "";
    }
    encodedPath = encodedPath.replace(/\/$/, "");
    return `:${encodeURIComponent(encodedPath)}`;
}
/**
 * Fetch the access token from Redis storage and check if the token requires a renew
 *
 * @returns Access token for OneDrive API
 */ async function getAccessToken() {
    const { accessToken , refreshToken  } = await (0,_utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__/* .getOdAuthTokens */ .H)();
    // Return in storage access token if it is still valid
    if (typeof accessToken === "string") {
        console.log("Fetch access token from storage.");
        return accessToken;
    }
    // Return empty string if no refresh token is stored, which requires the application to be re-authenticated
    if (typeof refreshToken !== "string") {
        console.log("No refresh token, return empty access token.");
        return "";
    }
    // Fetch new access token with in storage refresh token
    const body = new URLSearchParams();
    body.append("client_id", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().clientId));
    body.append("redirect_uri", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().redirectUri));
    body.append("client_secret", clientSecret);
    body.append("refresh_token", refreshToken);
    body.append("grant_type", "refresh_token");
    const resp = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post((_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().authApi), body, {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
    if ("access_token" in resp.data && "refresh_token" in resp.data) {
        const { expires_in , access_token , refresh_token  } = resp.data;
        await (0,_utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__/* .storeOdAuthTokens */ .$)({
            accessToken: access_token,
            accessTokenExpiry: parseInt(expires_in),
            refreshToken: refresh_token
        });
        return access_token;
    }
    return "";
}
/**
 * Match protected routes in site config to get path to required auth token
 * @param path Path cleaned in advance
 * @returns Path to required auth token. If not required, return empty string.
 */ function getAuthTokenPath(path) {
    // Ensure trailing slashes to compare paths component by component. Same for protectedRoutes.
    // Since OneDrive ignores case, lower case before comparing. Same for protectedRoutes.
    path = path.toLowerCase() + "/";
    const protectedRoutes = (_config_site_config__WEBPACK_IMPORTED_MODULE_3___default().protectedRoutes);
    let authTokenPath = "";
    for (let r of protectedRoutes){
        if (typeof r !== "string") continue;
        r = r.toLowerCase().replace(/\/$/, "") + "/";
        if (path.startsWith(r)) {
            authTokenPath = `${r}.password`;
            break;
        }
    }
    return authTokenPath;
}
/**
 * Handles protected route authentication:
 * - Match the cleanPath against an array of user defined protected routes
 * - If a match is found:
 * - 1. Download the .password file stored inside the protected route and parse its contents
 * - 2. Check if the od-protected-token header is present in the request
 * - The request is continued only if these two contents are exactly the same
 *
 * @param cleanPath Sanitised directory path, used for matching whether route is protected
 * @param accessToken OneDrive API access token
 * @param req Next.js request object
 * @param res Next.js response object
 */ async function checkAuthRoute(cleanPath, accessToken, odTokenHeader) {
    // Handle authentication through .password
    const authTokenPath = getAuthTokenPath(cleanPath);
    // Fetch password from remote file content
    if (authTokenPath === "") {
        return {
            code: 200,
            message: ""
        };
    }
    try {
        const token = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${(_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().driveApi)}/root${encodePath(authTokenPath)}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                select: "@microsoft.graph.downloadUrl,file"
            }
        });
        // Handle request and check for header 'od-protected-token'
        const odProtectedToken = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(token.data["@microsoft.graph.downloadUrl"]);
        // console.log(odTokenHeader, odProtectedToken.data.trim())
        if (!(0,_utils_protectedRouteHandler__WEBPACK_IMPORTED_MODULE_5__/* .compareHashedToken */ .Uc)({
            odTokenHeader: odTokenHeader,
            dotPassword: odProtectedToken.data.toString()
        })) {
            return {
                code: 401,
                message: "Password required."
            };
        }
    } catch (error) {
        // Password file not found, fallback to 404
        if (error?.response?.status === 404) {
            return {
                code: 404,
                message: "You didn't set a password."
            };
        } else {
            return {
                code: 500,
                message: "Internal server error."
            };
        }
    }
    return {
        code: 200,
        message: "Authenticated."
    };
}
async function handler(req, res) {
    // If method is POST, then the API is called by the client to store acquired tokens
    console.log("handle", req.method);
    if (req.method === "POST") {
        const { obfuscatedAccessToken , accessTokenExpiry , obfuscatedRefreshToken  } = req.body;
        const accessToken = revealObfuscatedToken(obfuscatedAccessToken);
        const refreshToken = revealObfuscatedToken(obfuscatedRefreshToken);
        if (typeof accessToken !== "string" || typeof refreshToken !== "string") {
            res.status(400).send("Invalid request body");
            return;
        }
        await storeOdAuthTokens({
            accessToken,
            accessTokenExpiry,
            refreshToken
        });
        res.status(200).send("OK");
        return;
    }
    // If method is GET, then the API is a normal request to the OneDrive API for files or folders
    const { path ="/" , raw =false , next ="" , sort =""  } = req.query;
    // Set edge function caching for faster load times, check docs:
    // https://vercel.com/docs/concepts/functions/edge-caching
    res.setHeader("Cache-Control", apiConfig.cacheControlHeader);
    // Sometimes the path parameter is defaulted to '[...path]' which we need to handle
    if (path === "[...path]") {
        res.status(400).json({
            error: "No path specified."
        });
        return;
    }
    // If the path is not a valid path, return 400
    if (typeof path !== "string") {
        res.status(400).json({
            error: "Path query invalid."
        });
        return;
    }
    // Besides normalizing and making absolute, trailing slashes are trimmed
    const cleanPath = pathPosix.resolve("/", pathPosix.normalize(path)).replace(/\/$/, "");
    // Validate sort param
    if (typeof sort !== "string") {
        res.status(400).json({
            error: "Sort query invalid."
        });
        return;
    }
    const accessToken = await getAccessToken();
    // Return error 403 if access_token is empty
    if (!accessToken) {
        res.status(403).json({
            error: "No access token."
        });
        return;
    }
    // Handle protected routes authentication
    const { code , message  } = await checkAuthRoute(cleanPath, accessToken, req.headers["od-protected-token"]);
    // Status code other than 200 means user has not authenticated yet
    if (code !== 200) {
        res.status(code).json({
            error: message
        });
        return;
    }
    // If message is empty, then the path is not protected.
    // Conversely, protected routes are not allowed to serve from cache.
    if (message !== "") {
        res.setHeader("Cache-Control", "no-cache");
    }
    const requestPath = encodePath(cleanPath);
    // Handle response from OneDrive API
    const requestUrl = `${apiConfig.driveApi}/root${requestPath}`;
    // Whether path is root, which requires some special treatment
    const isRoot = requestPath === "";
    // Go for file raw download link, add CORS headers, and redirect to @microsoft.graph.downloadUrl
    // (kept here for backwards compatibility, and cache headers will be reverted to no-cache)
    console.log("requestUrl", requestUrl);
    if (raw) {
        await runCorsMiddleware(req, res);
        res.setHeader("Cache-Control", "no-cache");
        const { data  } = await axios.get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                // OneDrive international version fails when only selecting the downloadUrl (what a stupid bug)
                select: "id,@microsoft.graph.downloadUrl"
            }
        });
        if ("@microsoft.graph.downloadUrl" in data) {
            res.redirect(data["@microsoft.graph.downloadUrl"]);
        } else {
            res.status(404).json({
                error: "No download url found."
            });
        }
        return;
    }
    // Querying current path identity (file or folder) and follow up query childrens in folder
    try {
        const { data: identityData  } = await axios.get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                select: "name,size,id,lastModifiedDateTime,folder,file,video,image"
            }
        });
        if ("folder" in identityData) {
            const { data: folderData  } = await axios.get(`${requestUrl}${isRoot ? "" : ":"}/children`, {
                headers: {
                    Authorization: `Bearer ${accessToken}`
                },
                params: {
                    ...{
                        select: "name,size,id,lastModifiedDateTime,folder,file,video,image",
                        $top: siteConfig.maxItems
                    },
                    ...next ? {
                        $skipToken: next
                    } : {},
                    ...sort ? {
                        $orderby: sort
                    } : {}
                }
            });
            // Extract next page token from full @odata.nextLink
            const nextPage = folderData["@odata.nextLink"] ? folderData["@odata.nextLink"].match(/&\$skiptoken=(.+)/i)[1] : null;
            // Return paging token if specified
            if (nextPage) {
                res.status(200).json({
                    folder: folderData,
                    next: nextPage
                });
            } else {
                res.status(200).json({
                    folder: folderData
                });
            }
            return;
        }
        res.status(200).json({
            file: identityData
        });
        return;
    } catch (error) {
        res.status(error?.response?.code ?? 500).json({
            error: error?.response?.data ?? "Internal server error."
        });
        return;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 115:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler),
/* harmony export */   "runCorsMiddleware": () => (/* binding */ runCorsMiddleware)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3582);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(cors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7384);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8092);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, ___WEBPACK_IMPORTED_MODULE_4__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, ___WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// CORS middleware for raw links: https://nextjs.org/docs/api-routes/api-middlewares
function runCorsMiddleware(req, res) {
    const cors = cors__WEBPACK_IMPORTED_MODULE_2___default()({
        methods: [
            "GET",
            "HEAD"
        ]
    });
    return new Promise((resolve, reject)=>{
        cors(req, res, (result)=>{
            if (result instanceof Error) {
                return reject(result);
            }
            return resolve(result);
        });
    });
}
async function handler(req, res) {
    const accessToken = await (0,___WEBPACK_IMPORTED_MODULE_4__/* .getAccessToken */ .hP)();
    if (!accessToken) {
        res.status(403).json({
            error: "No access token."
        });
        return;
    }
    const { path ="/" , odpt ="" , proxy =false  } = req.query;
    // Sometimes the path parameter is defaulted to '[...path]' which we need to handle
    if (path === "[...path]") {
        res.status(400).json({
            error: "No path specified."
        });
        return;
    }
    // If the path is not a valid path, return 400
    if (typeof path !== "string") {
        res.status(400).json({
            error: "Path query invalid."
        });
        return;
    }
    const cleanPath = path__WEBPACK_IMPORTED_MODULE_0__.posix.resolve("/", path__WEBPACK_IMPORTED_MODULE_0__.posix.normalize(path));
    // Handle protected routes authentication
    const odTokenHeader = req.headers["od-protected-token"] ?? odpt;
    const { code , message  } = await (0,___WEBPACK_IMPORTED_MODULE_4__/* .checkAuthRoute */ .GY)(cleanPath, accessToken, odTokenHeader);
    // Status code other than 200 means user has not authenticated yet
    if (code !== 200) {
        res.status(code).json({
            error: message
        });
        return;
    }
    // If message is empty, then the path is not protected.
    // Conversely, protected routes are not allowed to serve from cache.
    if (message !== "") {
        res.setHeader("Cache-Control", "no-cache");
    }
    await runCorsMiddleware(req, res);
    try {
        // Handle response from OneDrive API
        const requestUrl = `${_config_api_config__WEBPACK_IMPORTED_MODULE_3__.driveApi}/root${(0,___WEBPACK_IMPORTED_MODULE_4__/* .encodePath */ .Ec)(cleanPath)}`;
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                // OneDrive international version fails when only selecting the downloadUrl (what a stupid bug)
                select: "id,size,@microsoft.graph.downloadUrl"
            }
        });
        if ("@microsoft.graph.downloadUrl" in data) {
            // Only proxy raw file content response for files up to 4MB
            if (proxy && "size" in data && data["size"] < 4194304) {
                const { headers , data: stream  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(data["@microsoft.graph.downloadUrl"], {
                    responseType: "stream"
                });
                headers["Cache-Control"] = _config_api_config__WEBPACK_IMPORTED_MODULE_3__.cacheControlHeader;
                // Send data stream as response
                res.writeHead(200, headers);
                stream.pipe(res);
            } else {
                res.redirect(data["@microsoft.graph.downloadUrl"]);
            }
        } else {
            res.status(404).json({
                error: "No download url found."
            });
        }
        return;
    } catch (error) {
        res.status(error?.response?.status ?? 500).json({
            error: error?.response?.data ?? "Internal server error."
        });
        return;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7086:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jj": () => (/* binding */ revealObfuscatedToken)
/* harmony export */ });
/* unused harmony exports obfuscateToken, generateAuthorisationUrl, extractAuthCodeFromRedirected, requestTokenWithAuthCode, getAuthPersonInfo, sendTokenToServer */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7384);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// Just a disguise to obfuscate required tokens (including but not limited to client secret,
// access tokens, and refresh tokens), used along with the following two functions
const AES_SECRET_KEY = "onedrive-vercel-index";
function obfuscateToken(token) {
    // Encrypt token with AES
    const encrypted = CryptoJS.AES.encrypt(token, AES_SECRET_KEY);
    return encrypted.toString();
}
function revealObfuscatedToken(obfuscated) {
    // Decrypt SHA256 obfuscated token
    const decrypted = crypto_js__WEBPACK_IMPORTED_MODULE_1___default().AES.decrypt(obfuscated, AES_SECRET_KEY);
    return decrypted.toString((crypto_js__WEBPACK_IMPORTED_MODULE_1___default().enc.Utf8));
}
// Generate the Microsoft OAuth 2.0 authorization URL, used for requesting the authorisation code
function generateAuthorisationUrl() {
    const { clientId , redirectUri , authApi , scope  } = apiConfig;
    const authUrl = authApi.replace("/token", "/authorize");
    // Construct URL parameters for OAuth2
    const params = new URLSearchParams();
    params.append("client_id", clientId);
    params.append("redirect_uri", redirectUri);
    params.append("response_type", "code");
    params.append("scope", scope);
    params.append("response_mode", "query");
    return `${authUrl}?${params.toString()}`;
}
// The code returned from the Microsoft OAuth 2.0 authorization URL is a request URL with hostname
// http://localhost and URL parameter code. This function extracts the code from the request URL
function extractAuthCodeFromRedirected(url) {
    // Return empty string if the url is not the defined redirect uri
    if (!url.startsWith(apiConfig.redirectUri)) {
        return "";
    }
    // New URL search parameter
    const params = new URLSearchParams(url.split("?")[1]);
    return params.get("code") ?? "";
}
// After a successful authorisation, the code returned from the Microsoft OAuth 2.0 authorization URL
// will be used to request an access token. This function requests the access token with the authorisation code
// and returns the access token and refresh token on success.
async function requestTokenWithAuthCode(code) {
    const { clientId , redirectUri , authApi  } = apiConfig;
    const clientSecret = revealObfuscatedToken(apiConfig.obfuscatedClientSecret);
    // Construct URL parameters for OAuth2
    const params = new URLSearchParams();
    params.append("client_id", clientId);
    params.append("redirect_uri", redirectUri);
    params.append("client_secret", clientSecret);
    params.append("code", code);
    params.append("grant_type", "authorization_code");
    // Request access token
    return axios.post(authApi, params, {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    }).then((resp)=>{
        const { expires_in , access_token , refresh_token  } = resp.data;
        return {
            expiryTime: expires_in,
            accessToken: access_token,
            refreshToken: refresh_token
        };
    }).catch((err)=>{
        const { error , error_description , error_uri  } = err.response.data;
        return {
            error,
            errorDescription: error_description,
            errorUri: error_uri
        };
    });
}
// Verify the identity of the user with the access token and compare it with the userPrincipalName
// in the Microsoft Graph API. If the userPrincipalName matches, proceed with token storing.
async function getAuthPersonInfo(accessToken) {
    const profileApi = apiConfig.driveApi.replace("/drive", "");
    return axios.get(profileApi, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    });
}
async function sendTokenToServer(accessToken, refreshToken, expiryTime) {
    return await axios.post("/api", {
        obfuscatedAccessToken: obfuscateToken(accessToken),
        accessTokenExpiry: parseInt(expiryTime),
        obfuscatedRefreshToken: obfuscateToken(refreshToken)
    }, {
        headers: {
            "Content-Type": "application/json"
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ storeOdAuthTokens),
/* harmony export */   "H": () => (/* binding */ getOdAuthTokens)
/* harmony export */ });
/* harmony import */ var ioredis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1495);
/* harmony import */ var ioredis__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ioredis__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5386);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_site_config__WEBPACK_IMPORTED_MODULE_1__);


// Persistent key-value store is provided by Redis, hosted on Upstash
// https://vercel.com/integrations/upstash
const kv = new (ioredis__WEBPACK_IMPORTED_MODULE_0___default())(process.env.REDIS_URL || "");
async function getOdAuthTokens() {
    const accessToken = await kv.get(`${(_config_site_config__WEBPACK_IMPORTED_MODULE_1___default().kvPrefix)}access_token`);
    const refreshToken = await kv.get(`${(_config_site_config__WEBPACK_IMPORTED_MODULE_1___default().kvPrefix)}refresh_token`);
    return {
        accessToken,
        refreshToken
    };
}
async function storeOdAuthTokens({ accessToken , accessTokenExpiry , refreshToken  }) {
    await kv.set(`${(_config_site_config__WEBPACK_IMPORTED_MODULE_1___default().kvPrefix)}access_token`, accessToken, "EX", accessTokenExpiry);
    await kv.set(`${(_config_site_config__WEBPACK_IMPORTED_MODULE_1___default().kvPrefix)}refresh_token`, refreshToken);
}


/***/ }),

/***/ 4014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Uc": () => (/* binding */ compareHashedToken)
/* harmony export */ });
/* unused harmony exports getStoredToken, matchProtectedRoute */
/* harmony import */ var crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9172);
/* harmony import */ var crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5386);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_site_config__WEBPACK_IMPORTED_MODULE_1__);


// Hash password token with SHA256
function encryptToken(token) {
    return crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0___default()(token).toString();
}
// Fetch stored token from localStorage and encrypt with SHA256
function getStoredToken(path) {
    const storedToken =  false ? 0 : "";
    return storedToken ? encryptToken(storedToken) : null;
}
/**
 * Compares the hash of .password and od-protected-token header
 * @param odTokenHeader od-protected-token header (sha256 hashed token)
 * @param dotPassword non-hashed .password file
 * @returns whether the two hashes are the same
 */ function compareHashedToken({ odTokenHeader , dotPassword  }) {
    return encryptToken(dotPassword.trim()) === odTokenHeader;
}
/**
 * Match the specified route against a list of predefined routes
 * @param route directory path
 * @returns whether the directory is protected
 */ function matchProtectedRoute(route) {
    const protectedRoutes = siteConfig.protectedRoutes;
    let authTokenPath = "";
    for (const r of protectedRoutes){
        // protected route array could be empty
        if (r) {
            if (route.startsWith(r.split("/").map((p)=>encodeURIComponent(p)).join("/"))) {
                authTokenPath = r;
                break;
            }
        }
    }
    return authTokenPath;
}


/***/ })

};
;
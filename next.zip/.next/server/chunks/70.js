"use strict";
exports.id = 70;
exports.ids = [70];
exports.modules = {

/***/ 3070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Uc": () => (/* binding */ compareHashedToken),
/* harmony export */   "hV": () => (/* binding */ getStoredToken),
/* harmony export */   "ss": () => (/* binding */ matchProtectedRoute)
/* harmony export */ });
/* harmony import */ var crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9172);
/* harmony import */ var crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7534);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_site_config__WEBPACK_IMPORTED_MODULE_1__);


// Hash password token with SHA256
function encryptToken(token) {
    return crypto_js_sha256__WEBPACK_IMPORTED_MODULE_0___default()(token).toString();
}
// Fetch stored token from localStorage and encrypt with SHA256
function getStoredToken(path) {
    const storedToken =  false ? 0 : "";
    return storedToken ? encryptToken(storedToken) : null;
}
/**
 * Compares the hash of .password and od-protected-token header
 * @param odTokenHeader od-protected-token header (sha256 hashed token)
 * @param dotPassword non-hashed .password file
 * @returns whether the two hashes are the same
 */ function compareHashedToken({ odTokenHeader , dotPassword  }) {
    return encryptToken(dotPassword.trim()) === odTokenHeader;
}
/**
 * Match the specified route against a list of predefined routes
 * @param route directory path
 * @returns whether the directory is protected
 */ function matchProtectedRoute(route) {
    const protectedRoutes = (_config_site_config__WEBPACK_IMPORTED_MODULE_1___default().protectedRoutes);
    let authTokenPath = "";
    for (const r of protectedRoutes){
        // protected route array could be empty
        if (r) {
            if (route.startsWith(r.split("/").map((p)=>encodeURIComponent(p)).join("/"))) {
                authTokenPath = r;
                break;
            }
        }
    }
    return authTokenPath;
}


/***/ })

};
;
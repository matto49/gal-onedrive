"use strict";
(() => {
var exports = {};
exports.id = 237;
exports.ids = [237];
exports.modules = {

/***/ 6409:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkAuthRoute": () => (/* binding */ checkAuthRoute),
/* harmony export */   "default": () => (/* binding */ handler),
/* harmony export */   "encodePath": () => (/* binding */ encodePath),
/* harmony export */   "getAccessToken": () => (/* binding */ getAccessToken),
/* harmony export */   "getAuthTokenPath": () => (/* binding */ getAuthTokenPath)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3023);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7534);
/* harmony import */ var _config_site_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config_site_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7195);
/* harmony import */ var _utils_protectedRouteHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3070);
/* harmony import */ var _utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7937);
/* harmony import */ var _raw__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1563);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__, _raw__WEBPACK_IMPORTED_MODULE_7__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__, _raw__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const basePath = path__WEBPACK_IMPORTED_MODULE_0__.posix.resolve("/", (_config_site_config__WEBPACK_IMPORTED_MODULE_3___default().baseDirectory));
const clientSecret = (0,_utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__/* .revealObfuscatedToken */ .Jj)((_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().obfuscatedClientSecret));
/**
 * Encode the path of the file relative to the base directory
 *
 * @param path Relative path of the file to the base directory
 * @returns Absolute path of the file inside OneDrive
 */ function encodePath(path) {
    let encodedPath = path__WEBPACK_IMPORTED_MODULE_0__.posix.join(basePath, path);
    if (encodedPath === "/" || encodedPath === "") {
        return "";
    }
    encodedPath = encodedPath.replace(/\/$/, "");
    return `:${encodeURIComponent(encodedPath)}`;
}
/**
 * Fetch the access token from Redis storage and check if the token requires a renew
 *
 * @returns Access token for OneDrive API
 */ async function getAccessToken() {
    const { accessToken , refreshToken  } = await (0,_utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__/* .getOdAuthTokens */ .H)();
    // Return in storage access token if it is still valid
    if (typeof accessToken === "string") {
        console.log("Fetch access token from storage.");
        return accessToken;
    }
    // Return empty string if no refresh token is stored, which requires the application to be re-authenticated
    if (typeof refreshToken !== "string") {
        console.log("No refresh token, return empty access token.");
        return "";
    }
    // Fetch new access token with in storage refresh token
    const body = new URLSearchParams();
    body.append("client_id", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().clientId));
    body.append("redirect_uri", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().redirectUri));
    body.append("client_secret", clientSecret);
    body.append("refresh_token", refreshToken);
    body.append("grant_type", "refresh_token");
    const resp = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post((_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().authApi), body, {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
    if ("access_token" in resp.data && "refresh_token" in resp.data) {
        const { expires_in , access_token , refresh_token  } = resp.data;
        await (0,_utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__/* .storeOdAuthTokens */ .$)({
            accessToken: access_token,
            accessTokenExpiry: parseInt(expires_in),
            refreshToken: refresh_token
        });
        return access_token;
    }
    return "";
}
/**
 * Match protected routes in site config to get path to required auth token
 * @param path Path cleaned in advance
 * @returns Path to required auth token. If not required, return empty string.
 */ function getAuthTokenPath(path) {
    // Ensure trailing slashes to compare paths component by component. Same for protectedRoutes.
    // Since OneDrive ignores case, lower case before comparing. Same for protectedRoutes.
    path = path.toLowerCase() + "/";
    const protectedRoutes = (_config_site_config__WEBPACK_IMPORTED_MODULE_3___default().protectedRoutes);
    let authTokenPath = "";
    for (let r of protectedRoutes){
        if (typeof r !== "string") continue;
        r = r.toLowerCase().replace(/\/$/, "") + "/";
        if (path.startsWith(r)) {
            authTokenPath = `${r}.password`;
            break;
        }
    }
    return authTokenPath;
}
/**
 * Handles protected route authentication:
 * - Match the cleanPath against an array of user defined protected routes
 * - If a match is found:
 * - 1. Download the .password file stored inside the protected route and parse its contents
 * - 2. Check if the od-protected-token header is present in the request
 * - The request is continued only if these two contents are exactly the same
 *
 * @param cleanPath Sanitised directory path, used for matching whether route is protected
 * @param accessToken OneDrive API access token
 * @param req Next.js request object
 * @param res Next.js response object
 */ async function checkAuthRoute(cleanPath, accessToken, odTokenHeader) {
    // Handle authentication through .password
    const authTokenPath = getAuthTokenPath(cleanPath);
    // Fetch password from remote file content
    if (authTokenPath === "") {
        return {
            code: 200,
            message: ""
        };
    }
    try {
        const token = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${(_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().driveApi)}/root${encodePath(authTokenPath)}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                select: "@microsoft.graph.downloadUrl,file"
            }
        });
        // Handle request and check for header 'od-protected-token'
        const odProtectedToken = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(token.data["@microsoft.graph.downloadUrl"]);
        // console.log(odTokenHeader, odProtectedToken.data.trim())
        if (!(0,_utils_protectedRouteHandler__WEBPACK_IMPORTED_MODULE_5__/* .compareHashedToken */ .Uc)({
            odTokenHeader: odTokenHeader,
            dotPassword: odProtectedToken.data.toString()
        })) {
            return {
                code: 401,
                message: "Password required."
            };
        }
    } catch (error) {
        // Password file not found, fallback to 404
        if (error?.response?.status === 404) {
            return {
                code: 404,
                message: "You didn't set a password."
            };
        } else {
            return {
                code: 500,
                message: "Internal server error."
            };
        }
    }
    return {
        code: 200,
        message: "Authenticated."
    };
}
async function handler(req, res) {
    // If method is POST, then the API is called by the client to store acquired tokens
    console.log("handle", req.method);
    if (req.method === "POST") {
        const { obfuscatedAccessToken , accessTokenExpiry , obfuscatedRefreshToken  } = req.body;
        const accessToken = (0,_utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__/* .revealObfuscatedToken */ .Jj)(obfuscatedAccessToken);
        const refreshToken = (0,_utils_oAuthHandler__WEBPACK_IMPORTED_MODULE_4__/* .revealObfuscatedToken */ .Jj)(obfuscatedRefreshToken);
        if (typeof accessToken !== "string" || typeof refreshToken !== "string") {
            res.status(400).send("Invalid request body");
            return;
        }
        await (0,_utils_odAuthTokenStore__WEBPACK_IMPORTED_MODULE_6__/* .storeOdAuthTokens */ .$)({
            accessToken,
            accessTokenExpiry,
            refreshToken
        });
        res.status(200).send("OK");
        return;
    }
    // If method is GET, then the API is a normal request to the OneDrive API for files or folders
    const { path ="/" , raw =false , next ="" , sort =""  } = req.query;
    // Set edge function caching for faster load times, check docs:
    // https://vercel.com/docs/concepts/functions/edge-caching
    res.setHeader("Cache-Control", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().cacheControlHeader));
    // Sometimes the path parameter is defaulted to '[...path]' which we need to handle
    if (path === "[...path]") {
        res.status(400).json({
            error: "No path specified."
        });
        return;
    }
    // If the path is not a valid path, return 400
    if (typeof path !== "string") {
        res.status(400).json({
            error: "Path query invalid."
        });
        return;
    }
    // Besides normalizing and making absolute, trailing slashes are trimmed
    const cleanPath = path__WEBPACK_IMPORTED_MODULE_0__.posix.resolve("/", path__WEBPACK_IMPORTED_MODULE_0__.posix.normalize(path)).replace(/\/$/, "");
    // Validate sort param
    if (typeof sort !== "string") {
        res.status(400).json({
            error: "Sort query invalid."
        });
        return;
    }
    const accessToken = await getAccessToken();
    // Return error 403 if access_token is empty
    if (!accessToken) {
        res.status(403).json({
            error: "No access token."
        });
        return;
    }
    // Handle protected routes authentication
    const { code , message  } = await checkAuthRoute(cleanPath, accessToken, req.headers["od-protected-token"]);
    // Status code other than 200 means user has not authenticated yet
    if (code !== 200) {
        res.status(code).json({
            error: message
        });
        return;
    }
    // If message is empty, then the path is not protected.
    // Conversely, protected routes are not allowed to serve from cache.
    if (message !== "") {
        res.setHeader("Cache-Control", "no-cache");
    }
    const requestPath = encodePath(cleanPath);
    // Handle response from OneDrive API
    const requestUrl = `${(_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().driveApi)}/root${requestPath}`;
    // Whether path is root, which requires some special treatment
    const isRoot = requestPath === "";
    // Go for file raw download link, add CORS headers, and redirect to @microsoft.graph.downloadUrl
    // (kept here for backwards compatibility, and cache headers will be reverted to no-cache)
    console.log("requestUrl", requestUrl);
    if (raw) {
        await (0,_raw__WEBPACK_IMPORTED_MODULE_7__/* .runCorsMiddleware */ .l)(req, res);
        res.setHeader("Cache-Control", "no-cache");
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                // OneDrive international version fails when only selecting the downloadUrl (what a stupid bug)
                select: "id,@microsoft.graph.downloadUrl"
            }
        });
        if ("@microsoft.graph.downloadUrl" in data) {
            res.redirect(data["@microsoft.graph.downloadUrl"]);
        } else {
            res.status(404).json({
                error: "No download url found."
            });
        }
        return;
    }
    // Querying current path identity (file or folder) and follow up query childrens in folder
    try {
        const { data: identityData  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                select: "name,size,id,lastModifiedDateTime,folder,file,video,image"
            }
        });
        if ("folder" in identityData) {
            const { data: folderData  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${requestUrl}${isRoot ? "" : ":"}/children`, {
                headers: {
                    Authorization: `Bearer ${accessToken}`
                },
                params: {
                    ...{
                        select: "name,size,id,lastModifiedDateTime,folder,file,video,image",
                        $top: (_config_site_config__WEBPACK_IMPORTED_MODULE_3___default().maxItems)
                    },
                    ...next ? {
                        $skipToken: next
                    } : {},
                    ...sort ? {
                        $orderby: sort
                    } : {}
                }
            });
            // Extract next page token from full @odata.nextLink
            const nextPage = folderData["@odata.nextLink"] ? folderData["@odata.nextLink"].match(/&\$skiptoken=(.+)/i)[1] : null;
            // Return paging token if specified
            if (nextPage) {
                res.status(200).json({
                    folder: folderData,
                    next: nextPage
                });
            } else {
                res.status(200).json({
                    folder: folderData
                });
            }
            return;
        }
        res.status(200).json({
            file: identityData
        });
        return;
    } catch (error) {
        res.status(error?.response?.code ?? 500).json({
            error: error?.response?.data ?? "Internal server error."
        });
        return;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ runCorsMiddleware)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3582);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(cors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3023);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6409);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, ___WEBPACK_IMPORTED_MODULE_4__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, ___WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// CORS middleware for raw links: https://nextjs.org/docs/api-routes/api-middlewares
function runCorsMiddleware(req, res) {
    const cors = cors__WEBPACK_IMPORTED_MODULE_2___default()({
        methods: [
            "GET",
            "HEAD"
        ]
    });
    return new Promise((resolve, reject)=>{
        cors(req, res, (result)=>{
            if (result instanceof Error) {
                return reject(result);
            }
            return resolve(result);
        });
    });
}
async function handler(req, res) {
    const accessToken = await getAccessToken();
    if (!accessToken) {
        res.status(403).json({
            error: "No access token."
        });
        return;
    }
    const { path ="/" , odpt ="" , proxy =false  } = req.query;
    // Sometimes the path parameter is defaulted to '[...path]' which we need to handle
    if (path === "[...path]") {
        res.status(400).json({
            error: "No path specified."
        });
        return;
    }
    // If the path is not a valid path, return 400
    if (typeof path !== "string") {
        res.status(400).json({
            error: "Path query invalid."
        });
        return;
    }
    const cleanPath = pathPosix.resolve("/", pathPosix.normalize(path));
    // Handle protected routes authentication
    const odTokenHeader = req.headers["od-protected-token"] ?? odpt;
    const { code , message  } = await checkAuthRoute(cleanPath, accessToken, odTokenHeader);
    // Status code other than 200 means user has not authenticated yet
    if (code !== 200) {
        res.status(code).json({
            error: message
        });
        return;
    }
    // If message is empty, then the path is not protected.
    // Conversely, protected routes are not allowed to serve from cache.
    if (message !== "") {
        res.setHeader("Cache-Control", "no-cache");
    }
    await runCorsMiddleware(req, res);
    try {
        // Handle response from OneDrive API
        const requestUrl = `${driveApi}/root${encodePath(cleanPath)}`;
        const { data  } = await axios.get(requestUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            params: {
                // OneDrive international version fails when only selecting the downloadUrl (what a stupid bug)
                select: "id,size,@microsoft.graph.downloadUrl"
            }
        });
        if ("@microsoft.graph.downloadUrl" in data) {
            // Only proxy raw file content response for files up to 4MB
            if (proxy && "size" in data && data["size"] < 4194304) {
                const { headers , data: stream  } = await axios.get(data["@microsoft.graph.downloadUrl"], {
                    responseType: "stream"
                });
                headers["Cache-Control"] = cacheControlHeader;
                // Send data stream as response
                res.writeHead(200, headers);
                stream.pipe(res);
            } else {
                res.redirect(data["@microsoft.graph.downloadUrl"]);
            }
        } else {
            res.status(404).json({
                error: "No download url found."
            });
        }
        return;
    } catch (error) {
        res.status(error?.response?.status ?? 500).json({
            error: error?.response?.data ?? "Internal server error."
        });
        return;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* binding */ getOdAuthTokens),
  "$": () => (/* binding */ storeOdAuthTokens)
});

;// CONCATENATED MODULE: external "ioredis"
const external_ioredis_namespaceObject = require("ioredis");
var external_ioredis_default = /*#__PURE__*/__webpack_require__.n(external_ioredis_namespaceObject);
// EXTERNAL MODULE: ./config/site.config.js
var site_config = __webpack_require__(7534);
var site_config_default = /*#__PURE__*/__webpack_require__.n(site_config);
;// CONCATENATED MODULE: ./src/utils/odAuthTokenStore.ts


// Persistent key-value store is provided by Redis, hosted on Upstash
// https://vercel.com/integrations/upstash
const kv = new (external_ioredis_default())(process.env.REDIS_URL || "");
async function getOdAuthTokens() {
    const accessToken = await kv.get(`${(site_config_default()).kvPrefix}access_token`);
    const refreshToken = await kv.get(`${(site_config_default()).kvPrefix}refresh_token`);
    return {
        accessToken,
        refreshToken
    };
}
async function storeOdAuthTokens({ accessToken , accessTokenExpiry , refreshToken  }) {
    await kv.set(`${(site_config_default()).kvPrefix}access_token`, accessToken, "EX", accessTokenExpiry);
    await kv.set(`${(site_config_default()).kvPrefix}refresh_token`, refreshToken);
}


/***/ }),

/***/ 3582:
/***/ ((module) => {

module.exports = require("cors");

/***/ }),

/***/ 5666:
/***/ ((module) => {

module.exports = require("crypto-js");

/***/ }),

/***/ 9172:
/***/ ((module) => {

module.exports = require("crypto-js/sha256");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [534,70,23,195], () => (__webpack_exec__(6409)));
module.exports = __webpack_exports__;

})();
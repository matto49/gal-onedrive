(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8452:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7622);
/* harmony import */ var _fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1813);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_markdown_github_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1118);
/* harmony import */ var _styles_markdown_github_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_markdown_github_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _vercel_analytics_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9752);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2765);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4563);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(303);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _themes_antdTheme_config__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__, _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__]);
([_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_4__, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__, _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// Require had to be used to prevent SSR failure in Next.js
// Related discussion: https://github.com/FortAwesome/Font-Awesome/issues/19348
const { library , config  } = __webpack_require__(3195);

config.autoAddCss = false;






// import all brand icons with tree-shaking so all icons can be referenced in the app
const iconList = Object.keys(_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__).filter((k)=>k !== "fab" && k !== "prefix").map((icon)=>_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__[icon]);
library.add(_fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileImage, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFilePdf, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileWord, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFilePowerpoint, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileExcel, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileAudio, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileVideo, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileArchive, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileCode, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFileAlt, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFile, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFlag, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faFolder, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faMusic, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faArrowLeft, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faArrowRight, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faAngleRight, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faFileDownload, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faCopy, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faCopy, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faPlus, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faMinus, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faDownload, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faLink, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faUndo, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faBook, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faArrowAltCircleDown, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faKey, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faTrashAlt, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faSignOutAlt, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faEnvelope, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faCloud, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faChevronCircleDown, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faExternalLinkAlt, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faExclamationCircle, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faExclamationTriangle, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faHome, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faCheck, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faCheckCircle, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faSearch, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faChevronDown, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faTh, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faThLarge, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faThList, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faLanguage, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__.faPen, ...iconList);
function MyApp({ Component , pageProps  }) {
    const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_6__.QueryClient({
        defaultOptions: {
            queries: {
                staleTime: 10 * 1000,
                cacheTime: 10 * 1000,
                retry: 1
            }
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.ConfigProvider, {
        theme: _themes_antdTheme_config__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.App, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_query__WEBPACK_IMPORTED_MODULE_6__.QueryClientProvider, {
                client: queryClient,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_10___default()), {
                        height: 1,
                        color: "rgb(156, 163, 175, 0.9)",
                        options: {
                            showSpinner: false
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_4__.Analytics, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_i18next__WEBPACK_IMPORTED_MODULE_11__.appWithTranslation)(MyApp));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const antdTheme = {
    token: {
        fontSize: 16,
        colorText: "rgb(161 161 170)"
    },
    components: {
        Progress: {
            remainingColor: "rgb(161 161 170)",
            circleTextColor: "rgb(161 161 170)"
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (antdTheme);


/***/ }),

/***/ 7622:
/***/ (() => {



/***/ }),

/***/ 1813:
/***/ (() => {



/***/ }),

/***/ 1118:
/***/ (() => {



/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 1175:
/***/ ((module) => {

"use strict";
module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 303:
/***/ ((module) => {

"use strict";
module.exports = import("@fortawesome/free-brands-svg-icons");;

/***/ }),

/***/ 2765:
/***/ ((module) => {

"use strict";
module.exports = import("@fortawesome/free-regular-svg-icons");;

/***/ }),

/***/ 4563:
/***/ ((module) => {

"use strict";
module.exports = import("@fortawesome/free-solid-svg-icons");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

"use strict";
module.exports = import("@vercel/analytics/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8452));
module.exports = __webpack_exports__;

})();
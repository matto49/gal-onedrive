"use strict";
(() => {
var exports = {};
exports.id = 682;
exports.ids = [682,750];
exports.modules = {

/***/ 3582:
/***/ ((module) => {

module.exports = require("cors");

/***/ }),

/***/ 5666:
/***/ ((module) => {

module.exports = require("crypto-js");

/***/ }),

/***/ 9172:
/***/ ((module) => {

module.exports = require("crypto-js/sha256");

/***/ }),

/***/ 1495:
/***/ ((module) => {

module.exports = require("ioredis");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8676:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8092);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7384);
/* harmony import */ var _config_api_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_config_api_config__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, ___WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, ___WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function handler(req, res) {
    // Get access token from storage
    const accessToken = await (0,___WEBPACK_IMPORTED_MODULE_1__/* .getAccessToken */ .hP)();
    // Get item details (specifically, its path) by its unique ID in OneDrive
    const { id =""  } = req.query;
    // Set edge function caching for faster load times, check docs:
    // https://vercel.com/docs/concepts/functions/edge-caching
    res.setHeader("Cache-Control", (_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().cacheControlHeader));
    if (typeof id === "string") {
        const itemApi = `${(_config_api_config__WEBPACK_IMPORTED_MODULE_2___default().driveApi)}/items/${id}`;
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(itemApi, {
                headers: {
                    Authorization: `Bearer ${accessToken}`
                },
                params: {
                    select: "id,name,parentReference"
                }
            });
            res.status(200).json(data);
        } catch (error) {
            res.status(error?.response?.status ?? 500).json({
                error: error?.response?.data ?? "Internal server error."
            });
        }
    } else {
        res.status(400).json({
            error: "Invalid driveItem ID."
        });
    }
    return;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [280], () => (__webpack_exec__(8676)));
module.exports = __webpack_exports__;

})();